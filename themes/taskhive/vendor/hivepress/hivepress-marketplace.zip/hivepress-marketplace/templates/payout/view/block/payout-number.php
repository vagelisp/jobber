<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<td class="hp-payout__number">
	<strong>#<?php echo esc_html( $payout->get_id() ); ?></strong>
</td>
