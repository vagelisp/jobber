<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<div class="hp-offer__attribute hp-offer__attribute--price">
	<?php echo esc_html( $offer->display_price() ); ?>
</div>
