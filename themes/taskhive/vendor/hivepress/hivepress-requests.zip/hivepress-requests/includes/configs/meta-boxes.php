<?php
/**
 * Meta boxes configuration.
 *
 * @package HivePress\Configs
 */

use HivePress\Helpers as hp;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

return [
	'request_settings' => [
		'title'  => hivepress()->translator->get_string( 'settings' ),
		'screen' => 'request',
		'model'  => 'request',
		'fields' => [],
	],

	'request_images'   => [
		'title'  => hivepress()->translator->get_string( 'images' ),
		'screen' => 'request',
		'model'  => 'request',

		'fields' => [
			'images' => [
				'caption'   => hivepress()->translator->get_string( 'select_images' ),
				'type'      => 'attachment_upload',
				'multiple'  => true,
				'max_files' => 10,
				'formats'   => [ 'jpg', 'jpeg', 'png' ],
				'_order'    => 10,
			],
		],
	],
];
